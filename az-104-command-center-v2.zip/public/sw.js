// Service Worker do AZ-104 Command Center
// v2: estratégia network-first para páginas (o app sempre recebe a versão mais recente quando online)
// e cache-first apenas para arquivos estáticos com hash no nome (imutáveis).
const CACHE_NAME = 'az104-cache-v2';

// O escopo do SW é a pasta onde o app está publicado (ex.: https://usuario.github.io/repo/),
// então os caminhos são relativos a ele e funcionam em subpasta (GitHub Pages) ou na raiz (Azure, servidor próprio).
const SCOPE = self.registration.scope;
const ASSETS_TO_CACHE = [SCOPE, SCOPE + 'index.html', SCOPE + 'manifest.json'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS_TO_CACHE).catch(() => {}))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    )
  );
  self.clients.claim();
});

function putInCache(request, response) {
  if (!response || response.status !== 200 || response.type !== 'basic') return;
  const copy = response.clone();
  caches.open(CACHE_NAME).then((cache) => cache.put(request, copy));
}

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Ignora tudo que não seja GET do mesmo domínio, e chamadas de API
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.includes('/api/')) {
    return;
  }

  // Páginas (navegação) e manifest: rede primeiro, cache como reserva offline
  if (request.mode === 'navigate' || url.pathname.endsWith('/manifest.json')) {
    event.respondWith(
      fetch(request)
        .then((networkResponse) => {
          putInCache(request, networkResponse);
          return networkResponse;
        })
        .catch(() =>
          caches.match(request).then((cached) => cached || caches.match(SCOPE + 'index.html') || caches.match(SCOPE))
        )
    );
    return;
  }

  // Demais arquivos estáticos (JS/CSS com hash, ícones): cache primeiro, rede como complemento
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((networkResponse) => {
        putInCache(request, networkResponse);
        return networkResponse;
      });
    })
  );
});
